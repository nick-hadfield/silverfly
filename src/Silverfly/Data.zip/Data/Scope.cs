﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;

namespace Silverfly.Data
{
    /// <summary>
    /// The scope of the data context.
    /// </summary>
    /// <typeparam name="TDataContext"></typeparam>
    public class Scope<TDataContext> : IDisposable where TDataContext : DataContext, new()
    {
        /// <summary>
        /// the data context associated with this scope.
        /// </summary>
        private DataContext _context;

        /// <summary>
        /// Gets the data context associated with this scope.
        /// </summary>
        public DataContext Context
        {
            get { return _context; }
        }

        /// <summary>
        /// Initialises a new instance on the scope.
        /// </summary>
        public Scope()
        {
            _context = (DataContext)new TDataContext();
        }

        #region IDisposable Members

        /// <summary>
        /// Commits or rolls back the scope.
        /// </summary>
        public void Dispose()
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
